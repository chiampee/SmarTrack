/**
 * SmarTrack Chrome Extension Popup
 * Enhanced with selected text capture and metadata extraction
 */

class SmarTrackPopup {
  constructor() {
    this.tags = [];
    this.isProcessing = false;
    this.currentTab = null;
    this.pageData = {};
    this.selectedText = '';
    
    this.init();
  }

  async init() {
    try {
      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.currentTab = tab;
      
      // Check if user is logged in
      const token = await this.getAuthToken();
      
      // Always setup event listeners first
      this.setupEventListeners();
      
      if (!token) {
        // Show login view
        this.showLoginView();
      } else {
        // Extract page metadata
        await this.extractPageMetadata();
        
        // Check for selected text
        await this.captureSelectedText();
        
        // Populate UI
        this.populateUI();
        
        // Show main view
        this.showMainView();
      }
      
    } catch (error) {
      console.error('Failed to initialize popup:', error);
      this.showStatus('Failed to load page', 'error');
    }
  }

  showLoginView() {
    document.getElementById('loginView').classList.remove('hidden');
    document.getElementById('mainView').classList.add('hidden');
  }

  showMainView() {
    document.getElementById('loginView').classList.add('hidden');
    document.getElementById('mainView').classList.remove('hidden');
  }

  async extractPageMetadata() {
    try {
      // Execute content script to extract metadata
      const [result] = await chrome.scripting.executeScript({
        target: { tabId: this.currentTab.id },
        func: () => {
          const getMetaContent = (name) => {
            const meta = document.querySelector(`meta[name="${name}"], meta[property="${name}"]`);
            return meta ? meta.getAttribute('content') : null;
          };

          return {
            title: document.title,
            url: window.location.href,
            description: getMetaContent('description') || getMetaContent('og:description'),
            image: getMetaContent('og:image'),
            favicon: document.querySelector('link[rel="icon"]')?.getAttribute('href') || 
                     document.querySelector('link[rel="shortcut icon"]')?.getAttribute('href'),
            selectedText: window.getSelection().toString().trim()
          };
        }
      });
      
      this.pageData = result.result || {};
      
    } catch (error) {
      console.error('Failed to extract metadata:', error);
      this.pageData = {
        title: this.currentTab.title || 'Untitled',
        url: this.currentTab.url || '',
        description: '',
        favicon: null,
        selectedText: ''
      };
    }
  }

  async captureSelectedText() {
    try {
      // Check if there's selected text
      const [result] = await chrome.scripting.executeScript({
        target: { tabId: this.currentTab.id },
        func: () => window.getSelection().toString().trim()
      });
      
      this.selectedText = result.result || '';
      
      if (this.selectedText) {
        this.showSelectedTextInfo(this.selectedText);
      }
    } catch (error) {
      console.error('Failed to capture selected text:', error);
      this.selectedText = '';
    }
  }

  populateUI() {
    // Set page preview
    const titleEl = document.getElementById('pageTitle');
    const urlEl = document.getElementById('pageUrl');
    const faviconEl = document.getElementById('favicon');
    
    titleEl.textContent = this.pageData.title || this.currentTab.title || 'Untitled';
    urlEl.textContent = this.pageData.url || this.currentTab.url || '';
    
    // Set favicon
    if (this.pageData.favicon) {
      const faviconUrl = this.pageData.favicon.startsWith('http') 
        ? this.pageData.favicon 
        : new URL(this.pageData.favicon, this.pageData.url).href;
      faviconEl.style.backgroundImage = `url(${faviconUrl})`;
      faviconEl.style.backgroundSize = 'cover';
      faviconEl.style.backgroundPosition = 'center';
    }
    
    // Auto-fill title in form
    document.getElementById('title').value = this.pageData.title || this.currentTab.title || '';
    
    // Auto-fill description
    if (this.pageData.description) {
      document.getElementById('description').value = this.pageData.description;
    }
  }

  showSelectedTextInfo(text) {
    const infoEl = document.getElementById('selectedTextInfo');
    infoEl.textContent = `📝 Using selected text (${text.length} chars)`;
    infoEl.classList.remove('hidden');
  }

  setupEventListeners() {
    // Form submission
    const linkForm = document.getElementById('linkForm');
    if (linkForm) {
      linkForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleSave();
      });
    }

    // Tag input
    const tagInput = document.getElementById('tagInput');
    if (tagInput) {
      tagInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          e.preventDefault();
          const tag = tagInput.value.trim();
          if (tag) {
            this.addTag(tag);
            tagInput.value = '';
          }
        }
      });
    }

    // Cancel button
    const cancelBtn = document.getElementById('cancelBtn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        window.close();
      });
    }

    // Login button
    const loginBtn = document.getElementById('loginBtn');
    if (loginBtn) {
      loginBtn.addEventListener('click', () => {
        this.handleLogin();
      });
    }

    // Start background token checker
    this.startBackgroundTokenCheck();
  }

  startBackgroundTokenCheck() {
    // Check for token every 2 seconds if showing login view
    setInterval(async () => {
      const loginView = document.getElementById('loginView');
      if (loginView && !loginView.classList.contains('hidden')) {
        console.log('🔄 Checking for token in background...');
        const token = await this.getAuthToken();
        
        if (token) {
          console.log('✅ Token found! Reloading...');
          location.reload();
        }
      }
    }, 2000); // Check every 2 seconds
  }

  handleLogin() {
    // Open web app in new tab
    chrome.tabs.create({
      url: 'https://smar-track.vercel.app'
    });
    
    // Close popup
    window.close();
  }

  addTag(tagText) {
    if (tagText && !this.tags.includes(tagText)) {
      this.tags.push(tagText);
      this.renderTags();
    }
  }

  removeTag(tagText) {
    this.tags = this.tags.filter(tag => tag !== tagText);
    this.renderTags();
  }

  renderTags() {
    const container = document.getElementById('tagsContainer');
    container.innerHTML = '';
    
    this.tags.forEach(tag => {
      const tagEl = document.createElement('div');
      tagEl.className = 'tag';
      tagEl.innerHTML = `
        ${tag}
        <span class="tag-remove" data-tag="${tag}">×</span>
      `;
      
      tagEl.querySelector('.tag-remove').addEventListener('click', () => {
        this.removeTag(tag);
      });
      
      container.appendChild(tagEl);
    });
  }

  async handleSave() {
    if (this.isProcessing) return;
    
    try {
      this.isProcessing = true;
      this.showLoading(true);
      this.hideStatus();
      
      // Get auth token first
      const token = await this.getAuthToken();
      
      if (!token) {
        throw new Error('Please log in at https://smar-track.vercel.app first');
      }
      
      // Get form data
      const linkData = this.getLinkData();
      
      // Save to backend
      await this.saveLink(linkData, token);
      
      this.showStatus('✅ Link saved successfully!', 'success');
      
      // Auto-close after delay
      setTimeout(() => {
        window.close();
      }, 800);
      
    } catch (error) {
      console.error('Save failed:', error);
      this.showStatus(`❌ ${error.message}`, 'error');
    } finally {
      this.isProcessing = false;
      this.showLoading(false);
    }
  }

  getLinkData() {
    const url = this.pageData.url || this.currentTab.url;
    
    // Get content text - prefer selected text, fallback to page metadata description
    const content = this.selectedText || this.pageData.description || '';
    
    return {
      url: url,
      title: document.getElementById('title').value.trim(),
      description: document.getElementById('description').value.trim(),
      content: content, // Full text content (selected text or description)
      category: document.getElementById('category').value,
      tags: this.tags,
      contentType: this.detectContentType(url),
      thumbnail: this.pageData.image || null,
      favicon: this.pageData.favicon || null,
      isFavorite: false,
      isArchived: false
    };
  }

  detectContentType(url) {
    if (!url) return 'webpage';
    const urlLower = url.toLowerCase();
    
    if (urlLower.includes('.pdf')) return 'pdf';
    if (urlLower.includes('youtube.com') || urlLower.includes('vimeo.com')) return 'video';
    if (urlLower.match(/\.(jpg|jpeg|png|gif|webp)$/)) return 'image';
    if (urlLower.includes('arxiv.org') || urlLower.includes('scholar.google')) return 'article';
    if (urlLower.includes('.doc') || urlLower.includes('.docx')) return 'document';
    
    return 'webpage';
  }

  async saveLink(linkData) {
    try {
      // Get auth token
      const token = await this.getAuthToken();
      
      if (!token) {
        throw new Error('Please log in to SmarTrack first at https://smar-track.vercel.app');
      }
      
      // Save to backend
      const backendApi = new BackendApiService();
      await backendApi.saveLink(linkData, token);
      
    } catch (error) {
      console.error('Backend save failed:', error);
      throw error;
    }
  }

  async getAuthToken() {
    try {
      // First, try to get from Chrome storage
      const result = await chrome.storage.local.get(['authToken', 'tokenExpiry']);
      
      if (result.authToken) {
        // Check if token is valid (not expired)
        if (this.isTokenValid(result.tokenExpiry)) {
          return result.authToken;
        } else {
          console.log('⏰ Token expired, clearing...');
          await chrome.storage.local.remove(['authToken', 'tokenExpiry']);
        }
      }
      
      // Try to get from localStorage (current page)
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        const injectionResults = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => {
            try {
              return localStorage.getItem('authToken');
            } catch (e) {
              return null;
            }
          }
        });
        
        const token = injectionResults[0]?.result;
        
        if (token && this.isTokenValid(null, token)) {
          // Extract expiry from token
          const expiry = this.getTokenExpiry(token);
          // Store in Chrome storage with expiry
          await chrome.storage.local.set({ 
            authToken: token, 
            tokenExpiry: expiry 
          });
          return token;
        }
      } catch (e) {
        // Not a problem
      }
      
      return null;
      
    } catch (error) {
      console.error('Failed to get auth token:', error);
      return null;
    }
  }

  isTokenValid(expiry, token = null) {
    // If expiry is a timestamp
    if (expiry && expiry > Date.now()) {
      return true;
    }
    
    // Decode token to check expiry
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        const expiryTime = payload.exp * 1000; // Convert to milliseconds
        return expiryTime > Date.now();
      } catch (e) {
        return true; // Assume valid if can't decode
      }
    }
    
    return !expiry; // If no expiry stored and no token, assume not valid
  }

  getTokenExpiry(token) {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp * 1000; // Return in milliseconds
    } catch (e) {
      return null;
    }
  }

  showLoading(show) {
    const loading = document.getElementById('loading');
    const form = document.getElementById('linkForm');
    
    if (show) {
      loading.style.display = 'block';
      form.style.display = 'none';
    } else {
      loading.style.display = 'none';
      form.style.display = 'block';
    }
  }

  showStatus(message, type) {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = `status status-${type}`;
    status.classList.remove('hidden');
  }

  hideStatus() {
    const status = document.getElementById('status');
    status.classList.add('hidden');
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new SmarTrackPopup();
});
